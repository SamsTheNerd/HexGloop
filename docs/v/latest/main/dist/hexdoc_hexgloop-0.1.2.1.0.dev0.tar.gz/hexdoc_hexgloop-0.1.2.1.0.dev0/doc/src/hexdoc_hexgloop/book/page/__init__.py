__all__ = [
    "ItemFlayPage",
]

from .pages import (
    ItemFlayPage,
)